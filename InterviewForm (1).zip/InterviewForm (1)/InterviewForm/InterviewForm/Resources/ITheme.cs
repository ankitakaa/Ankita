﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InterviewForm.Resources
{
   public interface ITheme
    {
         void SetTheme(string color,Form1 form);

    }
}
