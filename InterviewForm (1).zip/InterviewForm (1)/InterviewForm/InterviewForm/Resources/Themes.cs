﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InterviewForm.Resources
{
   class Themes : ITheme
    {

       

        public void SetTheme(string color,Form1 form)
        {
              
                    form.BackColor = System.Drawing.Color.FromName(color);
                    form.Controls["button1"].BackColor = System.Drawing.Color.FromName(color);

                    foreach (Control myControl in form.Controls)
                    {
                        if (!(myControl is ComboBox)&&!(myControl is TextBox))
                        {
                            myControl.ForeColor = Color.White;
                            myControl.Font = new Font("Segoe UI", 10);
                        }
                        
                         
                    }
                                       
                   
                    
            

          
        }
    }
}
