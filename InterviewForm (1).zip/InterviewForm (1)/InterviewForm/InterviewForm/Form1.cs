﻿using InterviewForm.Resources;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace InterviewForm
{
    public partial class Form1 : Form
    {
        private readonly ITheme theme;
        public Form1(ITheme theme)
        {
            this.theme = theme;
            InitializeComponent();
        }

        

    private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
                       theme.SetTheme(comboBox2.Text,this);
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Name " + textBox1);
        }
    }
}
